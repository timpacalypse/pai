#!/usr/bin/env bash
# AEGIS Pi Agent — one-time setup script
# Run as: bash setup.sh
# Tested on Raspberry Pi OS 64-bit (Bookworm)

set -e

echo "=== AEGIS Pi Agent Setup ==="

# System packages
sudo apt-get update
sudo apt-get install -y \
    python3-pip python3-venv python3-dev \
    portaudio19-dev libportaudio2 \
    ffmpeg libsndfile1 \
    espeak-ng espeak-ng-data \
    libasound2-dev

# Create virtualenv
python3 -m venv venv
source venv/bin/activate

# Python dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Prepare local wake-model directory
mkdir -p models

# Copy env template if not already present
if [ ! -f .env ]; then
    cp .env.example .env
    echo ""
    echo ">>> IMPORTANT: edit .env and set PAI_HOST to your PAI server address"
    echo ">>> IMPORTANT: place your custom wake model at models/aegis.onnx"
    echo ""
fi

# Install systemd service
SERVICE_DIR=/etc/systemd/system
if [ -d "$SERVICE_DIR" ]; then
    sudo cp aegis-agent.service "$SERVICE_DIR/aegis-agent.service"
    sudo sed -i "s|/home/pi/aegis|$(pwd)|g" "$SERVICE_DIR/aegis-agent.service"
    sudo systemctl daemon-reload
    echo "systemd service installed. Start with: sudo systemctl start aegis-agent"
    echo "Enable on boot with: sudo systemctl enable aegis-agent"
fi

echo ""
echo "=== Setup complete ==="
echo "1. Edit .env — set PAI_HOST"
echo "2. Add wake model: models/aegis.onnx"
echo "3. Test: python agent.py"
echo "4. Enable service: sudo systemctl enable --now aegis-agent"
