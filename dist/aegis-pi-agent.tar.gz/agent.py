"""AEGIS Pi Voice Agent — always-on voice interface service.

Runs on the Raspberry Pi. Responsibilities:
  1. Continuously listen for the wake word "aegis" using openWakeWord
  2. On wake: record audio until silence
  3. POST audio (or text) to PAI orchestrator /voice/turn endpoint
  4. Receive response text + audio_b64 WAV
  5. Play TTS audio through speaker
  6. Return to wake-word listening

The AEGIS orb display (aegis.html) receives state changes automatically via
the orchestrator's WebSocket (/voice/ws) — this agent just drives the voice loop.

Setup:
  1. Copy this directory to the Pi
  2. pip install -r requirements.txt
  3. Download an openWakeWord model: aegis.onnx (or use the built-in hey_jarvis)
  4. Copy .env.example to .env and fill in PAI_HOST
  5. sudo systemctl enable/start aegis-agent (use aegis-agent.service)
  6. python agent.py  (or let systemd manage it)
"""

import asyncio
import base64
import io
import logging
import os
import sys
import tempfile
import time
import wave
from pathlib import Path

import httpx
import numpy as np
import sounddevice as sd
import soundfile as sf
from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")

# ── Configuration ─────────────────────────────────────────────────────────────

PAI_HOST = os.environ.get("PAI_HOST", "http://192.168.1.100:8000")
SAMPLE_RATE = 16000          # Hz — whisper and wake-word both expect 16kHz
CHANNELS = 1
CHUNK_SECONDS = 0.08         # 80ms chunks for wake-word inference
SILENCE_THRESHOLD = 0.012    # RMS below this = silence
SILENCE_AFTER_SPEECH = 1.6   # seconds of silence before stopping recording
MAX_RECORD_SECONDS = 30      # safety cap on recording
WAKE_WORD = os.environ.get("WAKE_WORD", "aegis")
WAKE_MODEL = os.environ.get("WAKE_MODEL", "models/aegis.onnx")
WAKE_THRESHOLD = float(os.environ.get("WAKE_THRESHOLD", "0.5"))
AUDIO_DEVICE = os.environ.get("AUDIO_DEVICE", None)      # None = system default
TELEGRAM_FORWARD = os.environ.get("TELEGRAM_FORWARD", "0") == "1"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stdout,
)
logger = logging.getLogger("aegis.agent")

# ── Wake word detector (lazy init) ────────────────────────────────────────────

_wake_model = None


def _get_wake_model():
    global _wake_model
    if _wake_model is not None:
        return _wake_model
    try:
        import openwakeword
        from openwakeword.model import Model
        wake_model_path = Path(WAKE_MODEL)
        if not wake_model_path.is_absolute():
            wake_model_path = (Path(__file__).parent / WAKE_MODEL).resolve()
        if not wake_model_path.exists():
            raise FileNotFoundError(
                f"Wake model not found at {wake_model_path}. Place your aegis.onnx model there or set WAKE_MODEL."
            )
        _wake_model = Model(wakeword_models=[str(wake_model_path)], inference_framework="onnx")
        logger.info(f"Wake-word model loaded: {WAKE_MODEL}")
    except Exception as e:
        logger.warning(f"openWakeWord not available ({e}) — using manual mode")
        _wake_model = None
    return _wake_model


# ── Audio utilities ────────────────────────────────────────────────────────────

def _rms(chunk: np.ndarray) -> float:
    return float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))


def _np_to_wav_bytes(audio: np.ndarray, rate: int = SAMPLE_RATE) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(2)  # 16-bit
        wf.setframerate(rate)
        wf.writeframes((audio * 32767).astype(np.int16).tobytes())
    buf.seek(0)
    return buf.read()


def record_until_silence(
    max_seconds: float = MAX_RECORD_SECONDS,
    silence_after: float = SILENCE_AFTER_SPEECH,
) -> np.ndarray:
    """Record from microphone until silence is detected."""
    logger.info("Recording started — speak now")
    frames = []
    silent_chunks = 0
    speaking = False
    chunks_per_second = int(1.0 / CHUNK_SECONDS)
    silence_chunk_limit = int(silence_after * chunks_per_second)
    max_chunks = int(max_seconds * chunks_per_second)

    chunk_size = int(SAMPLE_RATE * CHUNK_SECONDS)

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="float32",
        blocksize=chunk_size,
        device=AUDIO_DEVICE,
    ) as stream:
        for _ in range(max_chunks):
            chunk, _ = stream.read(chunk_size)
            rms = _rms(chunk)
            frames.append(chunk.copy())
            if rms > SILENCE_THRESHOLD:
                speaking = True
                silent_chunks = 0
            elif speaking:
                silent_chunks += 1
                if silent_chunks >= silence_chunk_limit:
                    break

    audio = np.concatenate(frames, axis=0).flatten()
    duration = len(audio) / SAMPLE_RATE
    logger.info(f"Recording complete: {duration:.1f}s")
    return audio


# ── PAI orchestrator calls ────────────────────────────────────────────────────

async def call_voice_turn(audio: np.ndarray) -> dict | None:
    """POST audio to PAI orchestrator /voice/turn, get response."""
    wav_bytes = _np_to_wav_bytes(audio)
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            resp = await client.post(
                f"{PAI_HOST}/voice/turn",
                files={"audio": ("recording.wav", wav_bytes, "audio/wav")},
                data={"telegram": "1" if TELEGRAM_FORWARD else "0"},
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPError as e:
            logger.error(f"PAI orchestrator call failed: {e}")
            return None


async def notify_wake() -> None:
    """Tell orchestrator we heard the wake word."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(f"{PAI_HOST}/voice/wake")
    except Exception:
        pass


async def notify_sleep() -> None:
    """Tell orchestrator we returned to dormant."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            await client.post(f"{PAI_HOST}/voice/sleep")
    except Exception:
        pass


# ── TTS playback ──────────────────────────────────────────────────────────────

def play_audio_b64(audio_b64: str) -> None:
    """Decode base64 WAV from orchestrator TTS and play through speaker."""
    try:
        import pygame
        wav_bytes = base64.b64decode(audio_b64)
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(wav_bytes)
            tmp = f.name
        pygame.mixer.init(frequency=22050, size=-16, channels=1, buffer=1024)
        pygame.mixer.music.load(tmp)
        pygame.mixer.music.play()
        while pygame.mixer.music.get_busy():
            time.sleep(0.05)
        pygame.mixer.quit()
        os.unlink(tmp)
    except Exception as e:
        logger.warning(f"Audio playback failed: {e}")


def speak_fallback(text: str) -> None:
    """Fallback TTS using espeak directly (always available on Pi)."""
    try:
        import subprocess
        subprocess.run(
            ["espeak-ng", "-v", "en-us", "-s", "145", text],
            check=True,
            timeout=15,
        )
    except Exception as e:
        logger.warning(f"espeak fallback failed: {e}")


def play_response(result: dict) -> None:
    """Play TTS audio or fall back to espeak."""
    if result.get("audio_b64"):
        play_audio_b64(result["audio_b64"])
    elif result.get("response_text"):
        speak_fallback(result["response_text"])


# ── Wake-word detection loop ──────────────────────────────────────────────────

async def listen_for_wake_word() -> bool:
    """Block until wake word is detected. Returns True on detection."""
    model = _get_wake_model()
    if model is None:
        logger.warning("No wake-word model — press ENTER to simulate wake")
        await asyncio.get_event_loop().run_in_executor(None, input)
        return True

    logger.info(f"Listening for wake word: '{WAKE_WORD}' ...")
    chunk_size = int(SAMPLE_RATE * CHUNK_SECONDS)
    loop = asyncio.get_event_loop()

    with sd.InputStream(
        samplerate=SAMPLE_RATE,
        channels=CHANNELS,
        dtype="int16",
        blocksize=chunk_size,
        device=AUDIO_DEVICE,
    ) as stream:
        while True:
            chunk, _ = await loop.run_in_executor(None, stream.read, chunk_size)
            scores = model.predict(chunk.flatten())
            score = max(scores.values()) if scores else 0.0
            if score >= WAKE_THRESHOLD:
                logger.info(f"Wake word detected (score={score:.2f})")
                return True


# ── Main conversation loop ────────────────────────────────────────────────────

async def run():
    logger.info(f"AEGIS voice agent started — PAI host: {PAI_HOST}")
    _get_wake_model()

    while True:
        try:
            # Phase 1: Wait for wake word
            detected = await listen_for_wake_word()
            if not detected:
                continue

            # Phase 2: Signal orchestrator (orb wakes up)
            await notify_wake()

            # Phase 3: Record speech
            loop = asyncio.get_event_loop()
            audio = await loop.run_in_executor(None, record_until_silence)

            # Phase 4: Send to PAI, get response
            result = await call_voice_turn(audio)
            if not result or result.get("error"):
                logger.warning(f"No response from PAI: {result}")
                await notify_sleep()
                continue

            logger.info(f"Transcript: {result.get('transcript', '')}")
            logger.info(f"Response: {result.get('response_text', '')[:120]}")

            # Phase 5: Play response audio
            play_response(result)

            # Phase 6: Return to sleep (orchestrator already handled this in /voice/turn)

        except KeyboardInterrupt:
            logger.info("AEGIS agent stopped by user")
            await notify_sleep()
            break
        except Exception as e:
            logger.error(f"Voice turn failed: {e}", exc_info=True)
            await notify_sleep()
            await asyncio.sleep(1)


if __name__ == "__main__":
    asyncio.run(run())
